#coding: utf-8
import os
from setuptools import setup, find_packages


def read(filename):
    return open(os.path.join(os.path.dirname(__file__), filename)).read()


setup(
    name="omnitransform",
    version="0.0.1",
    author="Martin Kjellberg",
    author_email="martin.kjellberg@mu.st",
    description=(""),
    license="BSD",
    keywords="",
    url="",
    packages=find_packages('src'),
    long_description=read('README.rst'),
    package_dir={'': 'omnitransform'},
    install_requires=[],
    python_requires='>=3.7',
)
# from distutils.core import setup

# setup(
#     name="omnitransfer",
#     version="0.0.1",
#     author="Martin Kjellberg",
#     author_email="martin.kjellberg@mu.st",
#     description="A small example package",
#     # long_description=long_description,
#     # long_description_content_type="text/markdown",
#     url="https://github.com/pypa/sampleproject",
#     packages=setuptools.find_packages(),
#     classifiers=[
#         "Programming Language :: Python :: 3",
#         "License :: OSI Approved :: MIT License",
#         "Operating System :: OS Independent",
#     ],
#     python_requires='>=3.7',
# )
